// 1. GESTÃO DO CARRINHO E FAVORITOS
let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
let favoritos = JSON.parse(localStorage.getItem('favoritos')) || [];

function adicionarAoCarrinho(nome, preco) {
    const produto = { nome, preco, quantidade: 1 };
    
    // Verifica se o produto já existe no carrinho
    const index = carrinho.findIndex(item => item.nome === nome); 
    
    if (index !== -1) {
        carrinho[index].quantidade++;
    } else {
        carrinho.push(produto);
    }

    alert(nome + " foi adicionado ao seu carrinho com sucesso!");

    guardarEDesenhar();
}

function removerDoCarrinho(index) {
    carrinho.splice(index, 1); 
    guardarEDesenhar();
}

function adicionarFavorito(nome, preco, imagem) {
    const index = favoritos.findIndex(item => item.nome === nome);
    
    if (index === -1) {
        favoritos.push({ nome, preco, imagem }); 
    } else {
        favoritos.splice(index, 1); // Se já lá estava, remove (funciona como um botão On/Off)
    }
    
    guardarEDesenhar();
}

// Parte visual dos corações
function atualizarCoracoes() {
    const botoesFavorito = document.querySelectorAll('.btn-favorito');
    
    botoesFavorito.forEach(btn => {
        // Lê o nome do produto que está no código onclick do HTML
        const onclickTexto = btn.getAttribute('onclick');
        if (!onclickTexto) return;

        const icone = btn.querySelector('i');
        
        // Verifica se este produto específico está gravado na lista de favoritos
        const taNosFavoritos = favoritos.some(fav => onclickTexto.includes(`'${fav.nome}'`) || onclickTexto.includes(`"${fav.nome}"`));

        if (taNosFavoritos) {
            icone.classList.remove('far'); // Remove coração vazio
            icone.classList.add('fas');    // Adiciona coração cheio
            btn.classList.add('favoritado');
        } else {
            icone.classList.remove('fas');
            icone.classList.add('far');
            btn.classList.remove('favoritado'); // Volta ao cinzento original
        }
    });
}

function atualizarContadorFavoritos() {
    const favoritos = JSON.parse(localStorage.getItem('favoritos')) || [];
    const contador = document.getElementById('contador-favoritos');
    
    if (contador) {
        contador.innerText = favoritos.length; // Coloca o número atual da lista
    }
}

function carregarFavoritos() {
    const grelha = document.getElementById('grelha-favoritos');
    if (!grelha) return; // Só corre se estivermos na página de favoritos

    // Vai buscar a lista guardada (ou cria uma vazia se não existir)
    const favoritos = JSON.parse(localStorage.getItem('favoritos')) || [];

    if (favoritos.length === 0) {
        grelha.innerHTML = "<p>Ainda não tens produtos favoritos.</p>";
        return;
    }


    // Limpa a grelha e desenha cada produto guardado
    grelha.innerHTML = favoritos.map(prod => `
        <article class="produto-card">
            <button class="btn-favorito favoritado" onclick="removerFavorito('${prod.nome}')">
                <i class="fas fa-heart"></i>
            </button>
            <div class="card-imagem">
                <img src="${prod.imagem}" alt="${prod.nome}">
            </div>
            <div class="produto-info">
                <h3 class="produto-titulo">${prod.nome}</h3>
                <div class="preco-area">
                    <p class="preco">${prod.preco}€</p>
                </div>
                <button class="btn-adicionar" onclick="adicionarAoCarrinho('${prod.nome}', ${prod.preco})">
                    <i class="fas fa-shopping-cart"></i> Adicionar
                </button>
            </div>
        </article>
    `).join('');
}

function removerFavorito(nomeProduto) {
    // 1. Vai buscar a lista atual
    let favoritos = JSON.parse(localStorage.getItem('favoritos')) || [];

    // 2. Filtra a lista para tirar o produto que clicámos
    favoritos = favoritos.filter(p => p.nome !== nomeProduto);

    // 3. Guarda a nova lista de volta no localStorage
    localStorage.setItem('favoritos', JSON.stringify(favoritos));

    // 4. ATUALIZA A INTERFACE NA HORA
    carregarFavoritos(); // Re-desenha a grelha
    atualizarContadorFavoritos(); // Atualiza o número no menu azul
}

// Executa a função assim que a página carrega
document.addEventListener('DOMContentLoaded', carregarFavoritos);

function guardarEDesenhar() {
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    localStorage.setItem('favoritos', JSON.stringify(favoritos));
    
    const contFavoritos = document.getElementById('contador-favoritos');
    if (contFavoritos) contFavoritos.innerText = favoritos.length;
    
    atualizarTabelaCarrinho();
    atualizarCoracoes(); // Garante que os corações atualizam sempre que gravamos
}

function atualizarTabelaCarrinho() {
    const corpoTabela = document.getElementById('corpo-carrinho');
    const valorTotalElemento = document.getElementById('valor-total');
    if (!corpoTabela) return;

    corpoTabela.innerHTML = '';
    let totalGeral = 0;

    carrinho.forEach((item, index) => {
        const subtotal = item.preco * item.quantidade;
        totalGeral += subtotal;
        const linha = document.createElement('tr');
        linha.innerHTML = `
            <td>${item.nome}</td>
            <td>${item.quantidade}</td>
            <td>${item.preco.toFixed(2)}€</td>
            <td>${subtotal.toFixed(2)}€</td>
            <td><button class="btn-remover" onclick="removerDoCarrinho(${index})"><i class="fas fa-trash"></i></button></td>
        `;
        corpoTabela.appendChild(linha);
    });
    if (valorTotalElemento) valorTotalElemento.innerText = totalGeral.toFixed(2) + "€";
}

// 2. PESQUISA E FILTRAGEM
function atualizarPrecoLabel(valor) {
    document.getElementById('preco-max-label').innerText = valor + "€";
    filtrarProdutos();
}

function filtrarProdutos() {
    const pesquisa = document.getElementById('barra-pesquisa').value.toLowerCase().trim();
    const catFiltro = document.getElementById('filtro-categoria').value;
    const precoMax = parseFloat(document.getElementById('filtro-preco').value);
    
    const produtos = document.querySelectorAll('.produto-card');

    produtos.forEach(p => {
        const titulo = p.querySelector('h3').textContent.toLowerCase();
        const precoTexto = p.querySelector('.preco').textContent;
        const precoNum = parseFloat(precoTexto.replace('€', '').replace(',', '.').trim());
        const categoria = p.getAttribute('data-categoria') || "todos";

        const matchNome = titulo.includes(pesquisa);
        const matchPreco = precoNum <= precoMax;
        const matchCategoria = (catFiltro === "todos" || categoria === catFiltro);

        if (matchNome && matchPreco && matchCategoria) {
            p.style.display = ""; 
        } else {
            p.style.display = "none";
        }
    });
}

// 3. LIMPAR FILTROS
function limparFiltros() {
    document.getElementById('barra-pesquisa').value = '';
    document.getElementById('filtro-categoria').value = 'todos';
    const sliderPreco = document.getElementById('filtro-preco');
    sliderPreco.value = sliderPreco.max;
    atualizarPrecoLabel(sliderPreco.max);
    filtrarProdutos();
}

// 4. VALIDAÇÃO DE REGISTO
function validarRegisto(event) {
    event.preventDefault();
    const user = document.getElementById('username').value;
    const pass = document.getElementById('pass').value;
    const termos = document.getElementById('termos').checked;

    if (user.length < 3 || pass.length < 6 || !termos) {
        alert("Verifica os dados e aceita os termos!");
        return;
    }
    alert(`Conta criada para: ${user}`);
    window.location.href = "produtos.html";
}

// Inicializa tudo quando a página carrega
window.onload = guardarEDesenhar;
